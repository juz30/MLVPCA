realsym=function(A){
  B=Re((A+t(A))/2)
  return(B)
}